﻿using mindware.Contents.Modules.Python;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace mindware
{
    /// <summary>
    /// Interaction logic for pycont.xaml
    /// </summary>
    public partial class pycont : Page
    {
        public pycont()
        {
            InitializeComponent();
        }

        private void BackButton_Homepage(object sender, RoutedEventArgs e)
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            if (mainWindow != null)
            {
                mainWindow.MainFrame.Content = null;
                // Call the reset function to show the main menu buttons again
                mainWindow.ResetToHomepage();
            }
        }

        private void CourseClickFunction(object sender, RoutedEventArgs e)
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            if (mainWindow != null)
            {
                mainWindow.MainFrame.Content = new courses();
            }
        }

        private void PracticeClickFunction(object sender, RoutedEventArgs e)
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            if (mainWindow != null)
            {
                mainWindow.MainFrame.Content = new practice();
            }
        }

        private void mod1fuPy(object sender, RoutedEventArgs e)
        {
            var MainWindow = Window.GetWindow(this) as MainWindow;
            if (MainWindow != null)
            {
                MainWindow.MainFrame.Content = new module1py();
            }
        }

        private void mod2fuPy(object sender, RoutedEventArgs e)
        {
            var MainWindow = Window.GetWindow(this) as MainWindow;
            if (MainWindow != null)
            {
                MainWindow.MainFrame.Content = new module2py();
            }
        }

        private void mod3fuPy(object sender, RoutedEventArgs e)
        {
            var MainWindow = Window.GetWindow(this) as MainWindow;
            if (MainWindow != null)
            {
                MainWindow.MainFrame.Content = new module3py();
            }
        }

        private void mod4fuPy(object sender, RoutedEventArgs e)
        {
            var MainWindow = Window.GetWindow(this) as MainWindow;
            if (MainWindow != null)
            {
                MainWindow.MainFrame.Content = new module4py();
            }
        }
    }
}
