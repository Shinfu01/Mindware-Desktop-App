﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace mindware.Contents.Modules.java
{
    /// <summary>
    /// Interaction logic for module4java.xaml
    /// </summary>
    public partial class module4java : Page
    {
        public module4java()
        {
            InitializeComponent();
        }

        private void BackButton_Homepage(object sender, RoutedEventArgs e)
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            if (mainWindow != null)
            {
                mainWindow.MainFrame.Content = null;
                // Call the reset function to show the main menu buttons again
                mainWindow.ResetToHomepage();
            }
        }

        private void BackButton_Java(object sender, RoutedEventArgs e)
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            if (mainWindow != null)
            {
                mainWindow.MainFrame.Content = new javacont();
            }
        }

        private void CourseClickFunction(object sender, RoutedEventArgs e)
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            if (mainWindow != null)
            {
                mainWindow.MainFrame.Content = new courses();
            }
        }

        private void PracticeClickFunction(object sender, RoutedEventArgs e)
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            if (mainWindow != null)
            {
                mainWindow.MainFrame.Content = new practice();
            }
        }
        private void ShowCongrats(object sender, RoutedEventArgs e)
        {
            // This makes the hidden congrats grid appear on top of the page
            CongratsOverlay.Visibility = Visibility.Visible;
        }
    }
}
