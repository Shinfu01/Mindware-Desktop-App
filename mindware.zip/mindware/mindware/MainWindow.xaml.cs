﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Interop;
using System.Runtime.InteropServices;

namespace mindware
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // THANKS dwampi LOL; DARK MODE FOR THE TITLE BAR
        [DllImport("dwmapi.dll")]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);
        public MainWindow()
        {
            InitializeComponent();
            DwmSetWindowAttribute(new WindowInteropHelper(this).EnsureHandle(), 20, ref new int[] { 1 }[0], sizeof(int));
        }

        public void ResetToHomepage()
        {
            coursebtn_main.Visibility = Visibility.Visible;
            practicebtn_main.Visibility = Visibility.Visible;
            hello.Visibility = Visibility.Visible;
            welcome.Visibility = Visibility.Visible;
            about.Visibility = Visibility.Visible;
        }

        public void ResetToPython()
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            if (mainWindow != null)
            {
                mainWindow.MainFrame.Content = new pycont();
            }
        }


        private void BackButton_Homepage(object sender, RoutedEventArgs e)
        {
            if (Window.GetWindow(this) is  MainWindow mainWindow)
            {
                mainWindow.MainFrame.Content = null;
                mainWindow.ResetToHomepage();
            }
        }

        private void CourseClickFunction(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new courses();
            coursebtn_main.Visibility = Visibility.Hidden;
            practicebtn_main.Visibility = Visibility.Hidden;
            hello.Visibility = Visibility.Hidden;
            welcome.Visibility = Visibility.Hidden;
            about.Visibility = Visibility.Hidden;

        }
        private void PracticeClickFunction(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new practice();

            coursebtn_main.Visibility = Visibility.Hidden;
            practicebtn_main.Visibility = Visibility.Hidden;
            hello.Visibility = Visibility.Hidden;
            welcome.Visibility = Visibility.Hidden;
            about.Visibility = Visibility.Hidden;
        }
    }
}
